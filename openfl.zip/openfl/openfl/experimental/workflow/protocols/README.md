# OpenFL Experimental gRPC protocols

All `*_pb2*` files are generated automatically during the installation via `pip`.
You can always build these files manually by running `python setup.py build_grpc` command from the root repository directory.
