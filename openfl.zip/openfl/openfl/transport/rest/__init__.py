# Copyright 2020-2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0


from openfl.transport.rest.aggregator_client import AggregatorRESTClient
from openfl.transport.rest.aggregator_server import AggregatorRESTServer
