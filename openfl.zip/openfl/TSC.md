# Technical Steering Committee members (alphabetical order)

Daniel J. Beutel;

Eric A. Stahlberg;

Layne Peng;

Micah J. Sheller; 

Patrick Foley [Chair];

Prashant Shah;

Spyridon Bakas;

