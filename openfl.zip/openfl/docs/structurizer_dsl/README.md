0. Structurizr DSL (diagram syntax) reference: <br>
https://github.com/structurizr/dsl/blob/master/docs/language-reference.md# <br>

1. Working with Structurizr CLI: <br>
Article: 
https://dev.to/simonbrown/getting-started-with-the-structurizr-cli-10c2 <br>
Git:
https://github.com/structurizr/cli/blob/master/README.md<br>

2. Using Structurizer CLI with Docker: <br>
https://github.com/aidmax/structurizr-cli-docker <br>

3. Rendering C4 models with Structurizr locally: <br>
https://dev.to/simonbrown/getting-started-with-structurizr-lite-27d0 <br>