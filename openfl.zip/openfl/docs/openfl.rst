.. currentmodule:: openfl

API Reference: ``openfl``
===========================

Subpackages
-----------

.. toctree::
    :maxdepth: 1

    reference/openfl.component
    reference/openfl.callbacks
    reference/openfl.cryptography
    reference/openfl.experimental
    reference/openfl.databases
    reference/openfl.federated
    reference/openfl.interface
    reference/openfl.pipelines
    reference/openfl.plugins
    reference/openfl.protocols
    reference/openfl.transport
    reference/openfl.utilities