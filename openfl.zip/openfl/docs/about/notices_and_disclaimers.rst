***********************
Notices and Disclaimers
***********************

Copyright (C) 2020-2024 Intel Corporation. Intel, the Intel logo, and other Intel marks are trademarks of Intel Corporation or its subsidiaries. Other names and brands may be claimed as the property of others. 

​​Intel technologies may require enabled hardware, software or service activation.​​​​

​No product or compon​ent can be absolutely secure. ​

Your costs and results may vary. 

​​No license (express or implied, by estoppel or otherwise) to any intellectual property rights is granted by this document.
