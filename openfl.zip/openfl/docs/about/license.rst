==========
License
==========

This project is licensed under `Apache License Version 2.0 <https://github.com/securefederatedai/openfl/blob/develop/LICENSE>`_. 
By contributing to the project, you agree to the license and copyright terms therein and release your contribution under these terms.