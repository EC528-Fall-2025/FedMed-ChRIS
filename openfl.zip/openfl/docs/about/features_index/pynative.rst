.. # Copyright (C) 2020-2023 Intel Corporation
.. # SPDX-License-Identifier: Apache-2.0

.. this page is not be included yet, so it's marked as an orphan.
.. Remove the below line when you're ready to publish this page.

:orphan:

=================
Python Native API (Deprecated)
=================

TODO

.. toctree
..    overview.how_can_intel_protect_federated_learning
..    overview.what_is_intel_federated_learning