``openfl.protocols`` module
===========================

.. currentmodule:: openfl.protocols

.. automodule:: openfl.protocols

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   interceptors
   utils

.. TODO(MasterSkepticista) Shrink API namespace
