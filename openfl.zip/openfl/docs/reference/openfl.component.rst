``openfl.component`` module
===========================

.. currentmodule:: openfl.component

.. automodule:: openfl.component

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   aggregator
   assigner
   collaborator
   straggler_handling_functions

.. TODO(MasterSkepticista) Shrink API namespace
