``fx plan`` command
====================

.. click:: openfl.interface.plan:plan
     :prog: fx plan
     :nested: full
