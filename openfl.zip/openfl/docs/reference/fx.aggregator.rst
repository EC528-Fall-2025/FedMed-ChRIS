``fx aggregator`` command
====================

.. click:: openfl.interface.aggregator:aggregator
    :prog: fx aggregator
    :nested: full
