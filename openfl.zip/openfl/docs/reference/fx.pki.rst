``fx pki`` command
====================

.. click:: openfl.interface.pki:pki
     :prog: fx pki
     :nested: full
