``fx model`` command
====================

.. click:: openfl.interface.model:model
     :prog: fx model
     :nested: full
