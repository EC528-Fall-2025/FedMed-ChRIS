``openfl.pipelines`` module
===========================

.. currentmodule:: openfl.pipelines

.. automodule:: openfl.pipelines

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   eden_pipeline
   kc_pipeline
   no_compression_pipeline
   pipeline
   random_shift_pipeline
   skc_pipeline
   stc_pipeline
   tensor_codec

.. TODO(MasterSkepticista) Shrink API namespace
