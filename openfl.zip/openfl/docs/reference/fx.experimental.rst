``fx experimental`` command
====================

.. click:: openfl.interface.experimental:experimental
     :prog: fx experimental
     :nested: full
