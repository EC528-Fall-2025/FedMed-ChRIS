``openfl.federated`` module
===========================

.. currentmodule:: openfl.federated

.. automodule:: openfl.federated

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   plan
   task
   data

.. TODO(MasterSkepticista) Shrink API namespace
