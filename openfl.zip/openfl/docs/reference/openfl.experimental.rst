``openfl.experimental`` module
==============================

.. currentmodule:: openfl.experimental

.. automodule:: openfl.experimental

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   workflow.interface
   workflow.placement
   workflow.runtime
   workflow.utilities

.. TODO(MasterSkepticista) Shrink API namespace
