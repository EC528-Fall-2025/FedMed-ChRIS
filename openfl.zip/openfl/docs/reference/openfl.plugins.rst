``openfl.plugins`` module
=========================

.. currentmodule:: openfl.plugins

.. automodule:: openfl.plugins

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   frameworks_adapters
   interface_serializer
   processing_units_monitor

.. TODO(MasterSkepticista) Shrink API namespace
