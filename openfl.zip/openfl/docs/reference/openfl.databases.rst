``openfl.databases`` module
===========================

.. currentmodule:: openfl.databases

.. automodule:: openfl.databases

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   tensor_db
   utilities

.. TODO(MasterSkepticista) Shrink API namespace
