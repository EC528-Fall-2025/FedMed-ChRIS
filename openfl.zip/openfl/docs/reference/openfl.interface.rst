``openfl.interface`` module
===========================

.. currentmodule:: openfl.interface

.. automodule:: openfl.interface

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   aggregation_functions
   aggregator
   cli_helper
   cli
   collaborator
   experimental
   model
   pki
   plan
   tutorial
   workspace

.. TODO(MasterSkepticista) Shrink API namespace
