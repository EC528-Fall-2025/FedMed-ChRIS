``openfl.utilities`` module
===========================


.. currentmodule:: openfl.utilities

.. automodule:: openfl.utilities

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   ca
   data_splitters
   fedcurv
   optimizers
   ca
   checks
   click_types
   dataloading
   fed_timer
   logs
   mocks
   path_check
   split
   types
   utils
   workspace
   