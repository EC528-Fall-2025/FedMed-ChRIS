``openfl.cryptography`` module
==============================

.. currentmodule:: openfl.cryptography

.. automodule:: openfl.cryptography

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   ca
   io
   participant

.. TODO(MasterSkepticista) Shrink API namespace
