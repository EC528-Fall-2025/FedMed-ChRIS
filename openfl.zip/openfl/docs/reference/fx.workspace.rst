``fx workspace`` command
====================

.. click:: openfl.interface.workspace:workspace
     :prog: fx workspace
     :nested: full
