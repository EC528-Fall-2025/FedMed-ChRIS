``openfl.callbacks`` module
===========================

.. currentmodule:: openfl.callbacks

.. automodule:: openfl.callbacks

.. autosummary::
   :toctree: _autosummary
   :recursive:

   Callback
   CallbackList
   LambdaCallback
   MetricWriter
   MemoryProfiler
