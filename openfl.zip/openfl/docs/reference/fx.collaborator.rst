``fx collaborator`` command
====================

.. click:: openfl.interface.collaborator:collaborator
     :prog: fx collaborator
     :nested: full
