.. # Copyright (C) 2020-2023 Intel Corporation
.. # SPDX-License-Identifier: Apache-2.0

.. this page is not be included yet, so it's marked as an orphan.
.. Remove the below line when you're ready to publish this page.

:orphan:

.. _running_the_federation_singularity:

Running on Singularity
######################

TODO

