# Update documentation
For more information, refer [here](https://openfl.readthedocs.io/en/latest/contributing.html#update-documentation).
